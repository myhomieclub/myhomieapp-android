<template>
  <div class="information">
  	<headTop :title="$t('inform.name')" v-bind:headBtn='false'>
  	  <!-- <span class="header_right" slot="right">
        <i class="iconfont icon-search" @click="search" style="font-size: 20px;"></i>
      </span> -->
  	</headTop>
    <div class="topBlank"></div>
  	<div class="information_select">
  		<div class="information_item" v-for="item in informations" @click="goto(item.page,item.name)">
  			<div class="item_img"><img src="../../common/images/111.jpg"></div>
  			<div class="cont">{{item.name}}</div>
  		</div>
  	</div>
    <div class="bottomBlank"></div>
  </div>
</template>

<script>
  import headTop from '../../components/headTop.vue';
  export default {
	  components: {
      headTop,
    },
    data() {
      return {
        informations: [
          {name: this.$t('inform.item1'), icon: '', page: 'event'},
          {name: this.$t('inform.item2'), icon: '', page: 'travel'},
          {name: this.$t('inform.item3'), icon: '', page: 'entrepreneurship'},
          {name: this.$t('inform.item4'), icon: '', page: 'chinese'},
          {name: this.$t('inform.item5'), icon: '', page: 'rent'},
          {name: this.$t('inform.item6'), icon: '', page: '2nd_hand'},
          {name: this.$t('inform.item7'), icon: '', page: 'sales'},
          {name: this.$t('inform.item8'), icon: '', page: 'recruitment'},
          {name: this.$t('inform.item9'), icon: '', page: 'others'},
        ]
      }
    },
    methods: {
      search() {
        this.$router.push({name: 'search', params: {type: 2}});
      },
      goto(type,name) {
        this.$router.push({name: 'informationList', params: {type: type}, query: {name: name}});
      }
    }
  }
</script>

<style lang="less">
@import '../../common/style/information.less';
</style>